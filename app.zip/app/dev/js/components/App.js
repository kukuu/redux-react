//Bundles containers
import React from 'react';
import UserList from '../containers/user-list';
import UserDetails from '../containers/user-detail';


require('../../scss/style.scss');

const App = () => (
    <div>
        
    	<h1>The Next Gen VLP  -  PZ1A VC< br /> (Spinning car image)</h1>
    	
        <h3>(animating text - GSAP starts) Make it your own</h3>
        <h3>Engaging</h3>
        <h3> Personalised experience</h3>
        <UserList />
        <hr />
        <UserDetails />

    </div>
);

export default App;


