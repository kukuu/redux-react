# Containers

Containers fetch state data and use it to render components.
- state data will become components props

Containers are similar to components. However, only containers have access to state data in Redux. They are SMART.
- components are sometimes called "dumb components" or "presentational components"
